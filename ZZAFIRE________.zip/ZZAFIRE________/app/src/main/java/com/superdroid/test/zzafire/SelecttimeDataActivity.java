package com.superdroid.test.zzafire;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class SelecttimeDataActivity extends AppCompatActivity {
    Button btn_date;
    RadioButton btn_date1;
    RadioButton btn_date2;

    TextView text_date1;
    TextView text_date2;
    Calendar c = Calendar.getInstance();

    int myear;
    int mmonth;
    int mmonth2;
    int mday;
    int mday2;

    ListView listView_up;//리스트뷰 객체
    BleListViewAdapter bleList = null;//리스트 어댑터

    ListView listView_down;
    GraphListViewAdapter graphList = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecttime_data);

        btn_date = (Button) findViewById(R.id.btn_date);
        btn_date1 = (RadioButton) findViewById(R.id.btn_date1);
        btn_date2 = (RadioButton) findViewById(R.id.btn_date2);
        text_date1 = (TextView) findViewById(R.id.text_date1);
        text_date2 = (TextView) findViewById(R.id.text_date2);

        myear = c.get(Calendar.YEAR);
        mmonth = c.get(Calendar.MONTH);
        mday = c.get(Calendar.DAY_OF_MONTH);

        bleList = new BleListViewAdapter(this);
        listView_up = (ListView) findViewById(R.id.listView_selecttime);
        listView_up.setAdapter(bleList);

        addDevice_Test("기기명 1");
        addDevice_Test("기기명 2");

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                addDevice_Test("기기명 3");
            }
        }, 500);

        graphList = new GraphListViewAdapter(getApplicationContext());
        listView_down = (ListView) findViewById(R.id.listView_graph2);
        listView_down.setAdapter(graphList);

        listView_up.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(getApplicationContext(), "시작", Toast.LENGTH_SHORT).show();

                if (bleList.getIsCheck(position)) {
                    graphList.removePoint(position);
                    graphList.notifyDataSetChanged();
                } else {
                    //DeviceInfo 테이블에 저장된 HRData를 얻어오기 위해서, infos 라는 객체를 생성하여서 접근한다.
                    List<DeviceInfo> infos = DeviceInfo.listAll(DeviceInfo.class);
                    //////////요기엥
                    //라디어보튼 체크에 따라 ->
                    if(btn_date1.isChecked())
                    {
                        String date1 = text_date1.getText().toString();
                        String[] yearMonth = date1.split("/");

                        List<DeviceInfo> info1 = DeviceInfo.find(DeviceInfo.class, "year=? and month=?", yearMonth, null, "day asc", "1");
                        List<DeviceInfo> info2 = DeviceInfo.find(DeviceInfo.class, "year=? and month=?", yearMonth, null, "day desc", "1");
                        int dayStart = Integer.parseInt(info1.get(0).day);
						int dayEnd = Integer.parseInt(info2.get(0).day);

						ArrayList<Point> points = new ArrayList<Point>();

						for (int i = dayStart; i <= dayEnd; i++) {
							String year = yearMonth[0];
							String month = yearMonth[1];
							String day = Integer.toString(i);

							info1.clear();
							info1 = DeviceInfo.find(DeviceInfo.class, "year=? and month=? and day=?", new String[] {year, month, day}, null, "day", null);

							int sum = 0;

							for (int j = 0; j < info1.size(); j++) {
								sum += Integer.parseInt(info1.get(j).hrdata);
							}

							points.add(new Point(i, (int)(sum / info1.size())));
						}

						Point[] p = new Point[points.size()];
						p = points.toArray(p);

						addPoint_Test(p);
                    }
                }

                bleList.setIsCheck(position);
                bleList.notifyDataSetChanged();
            }
        });
    }

    public void addDevice_Test(String device) {
        bleList.addDevice(device);
        bleList.notifyDataSetChanged();
    }

    public void addPoint_Test(Point[] point) {
        graphList.addPoint(point);
        graphList.notifyDataSetChanged();
    }

    DatePickerDialog.OnDateSetListener dateSetListener1 = new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            myear = year;
            mmonth = monthOfYear + 1;
            mday = dayOfMonth;
            mday2 = dayOfMonth + 1;
            text_date1.setText(myear + "/" + mmonth + "/" + mday);
            text_date2.setText(myear + "/" + mmonth + "/" + mday2);
        }
    };



    public void disableDayField(DatePickerDialog datePickerDialog) {
        try {
            Field[] f = datePickerDialog.getClass().getDeclaredFields();
            datePickerDialog.getDatePicker().setSpinnersShown(true);

            for (Field dateField : f) {
                if (dateField.getName().equals("mDayPicker") ||
                        dateField.getName().equals("mDaySpinner") ||
                        dateField.getName().equals("mDatePicker")) {
                    dateField.setAccessible(true);

                    DatePicker datePicker = (DatePicker) dateField.get(datePickerDialog);
                    Field datePickerFields[] = dateField.getType().getDeclaredFields();


                    // Lollipop 이후 버전
                    if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        int daySpinnerId = Resources.getSystem().getIdentifier("day", "id", "android");
                        if (daySpinnerId != 0) {
                            View daySpinner = datePicker.findViewById(daySpinnerId);
                            if(daySpinner != null) {
                                daySpinner.setVisibility(View.GONE);
                            }
                        }
                    }

                    // Lollipop 이전 버전
                    else {
                        for (Field datePickerField : datePickerFields) {
                            if (datePickerField.getName().contains("mDay")) {
                                datePickerField.setAccessible(true);
                                Object dayPicker = new Object();
                                dayPicker = datePickerField.get(datePicker);

                                try {
                                    ((View) dayPicker).setVisibility(View.GONE);
                                } catch (ClassCastException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }

                }
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        datePickerDialog.show();
    }

    DatePickerDialog.OnDateSetListener dateSetListener2 = new DatePickerDialog.OnDateSetListener() {
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            myear = year;
            mmonth = monthOfYear + 1;
            mmonth2 = mmonth +1;
            text_date1.setText(myear + "/" + mmonth);
            text_date2.setText(myear + "/" + mmonth2);
        }
    };


    public void mOnClick_date1(View v){
        Dialog datepicker = new DatePickerDialog(SelecttimeDataActivity.this,dateSetListener1,myear,mmonth,mday);
        DatePickerDialog datePickerDialog = new DatePickerDialog(SelecttimeDataActivity.this,android.R.style.Theme_Holo_Dialog_MinWidth, dateSetListener2, myear, mmonth, mday);
        if(btn_date1.isChecked()==true) {
            disableDayField(datePickerDialog);
            datePickerDialog.show();
        }

        if(btn_date2.isChecked()==true) {
            datepicker.show();
        }
    }
}

